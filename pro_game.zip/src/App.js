import React,{Component} from 'react';
import {BrowserRouter, Switch, Route} from 'react-router-dom';
import './App.css';
import Info from './components/Info';
import L1 from './components/L1';
import L2 from './components/L2';
import L4 from './components/L4';

class App extends Component {
	render() {
		return(
			<BrowserRouter>
				<Switch>
				<Route exact path='/' component={Info}/>
				<Route exact path='/l1' component={L1}/>
				<Route exact path='/l2' component={L2}/>
				<Route exact path='/l4' component={L4}/>
				</Switch>
      		</BrowserRouter>
		)
	}
}

export default App;
